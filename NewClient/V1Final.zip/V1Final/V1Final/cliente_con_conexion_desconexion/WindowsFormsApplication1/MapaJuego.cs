﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class MapaJuego : Form
    {
        public MapaJuego()
        {
            InitializeComponent();
        }

        private void buttonG1_Click(object sender, EventArgs e)
        {
            G1 form = new G1();
            form.ShowDialog();
            //this.Close();

        }

        private void Vermella_Click(object sender, EventArgs e)
        {
            Vermella form = new Vermella();
            form.ShowDialog();
        }
    }
}
