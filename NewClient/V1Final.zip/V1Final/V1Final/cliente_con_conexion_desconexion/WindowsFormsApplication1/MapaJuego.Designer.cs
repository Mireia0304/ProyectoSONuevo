﻿namespace WindowsFormsApplication1
{
    partial class MapaJuego
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Mapa = new System.Windows.Forms.Panel();
            this.buttonG1 = new System.Windows.Forms.Button();
            this.Vermella = new System.Windows.Forms.Button();
            this.Mapa.SuspendLayout();
            this.SuspendLayout();
            // 
            // Mapa
            // 
            this.Mapa.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.pmta_p01;
            this.Mapa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Mapa.Controls.Add(this.Vermella);
            this.Mapa.Controls.Add(this.buttonG1);
            this.Mapa.Location = new System.Drawing.Point(334, 13);
            this.Mapa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Mapa.Name = "Mapa";
            this.Mapa.Size = new System.Drawing.Size(762, 385);
            this.Mapa.TabIndex = 0;
            // 
            // buttonG1
            // 
            this.buttonG1.Location = new System.Drawing.Point(224, 208);
            this.buttonG1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonG1.Name = "buttonG1";
            this.buttonG1.Size = new System.Drawing.Size(53, 32);
            this.buttonG1.TabIndex = 0;
            this.buttonG1.Text = "buttonG1";
            this.buttonG1.UseVisualStyleBackColor = true;
            this.buttonG1.Click += new System.EventHandler(this.buttonG1_Click);
            // 
            // Vermella
            // 
            this.Vermella.Location = new System.Drawing.Point(77, 163);
            this.Vermella.Name = "Vermella";
            this.Vermella.Size = new System.Drawing.Size(68, 28);
            this.Vermella.TabIndex = 1;
            this.Vermella.Text = "button1";
            this.Vermella.UseVisualStyleBackColor = true;
            this.Vermella.Click += new System.EventHandler(this.Vermella_Click);
            // 
            // MapaJuego
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1173, 646);
            this.Controls.Add(this.Mapa);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MapaJuego";
            this.Text = "MapaJuego";
            this.Mapa.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Mapa;
        private System.Windows.Forms.Button buttonG1;
        private System.Windows.Forms.Button Vermella;
    }
}