﻿namespace WindowsFormsApplication1
{
    partial class G1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonLlum = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonLlum
            // 
            this.buttonLlum.Location = new System.Drawing.Point(33, 259);
            this.buttonLlum.Name = "buttonLlum";
            this.buttonLlum.Size = new System.Drawing.Size(20, 25);
            this.buttonLlum.TabIndex = 0;
            this.buttonLlum.Text = "buttonLlum";
            this.buttonLlum.UseVisualStyleBackColor = true;
            this.buttonLlum.Click += new System.EventHandler(this.buttonLlum_Click);
            // 
            // G1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.Groga1llum;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(836, 540);
            this.Controls.Add(this.buttonLlum);
            this.DoubleBuffered = true;
            this.Name = "G1";
            this.Text = "G1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonLlum;
    }
}